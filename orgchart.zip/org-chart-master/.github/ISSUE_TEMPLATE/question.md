---
name: Question
about: Have a question about the functionality of project
title: ''
labels: ''
assignees: ''

---

Before submitting an issue, please make sure to check whether the similar question was asked before. 
You can search for it here - https://github.com/bumbeishvili/d3-organization-chart/issues


